import React, { Component } from "react";
function not_found() {
	return (<div><strong>Route Not Found! - 404</strong></div>);
}

export default not_found