const db=require("./db");
module.exports = {
	db: db
};